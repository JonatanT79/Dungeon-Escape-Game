﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Labb_4
{
    enum Rutor
    {
        N, Y, V, D, U, M  // Enum för olika sorters rutor
    }
    class Föremål
    {
        // *** Enum ***
        //  En klass med föremål
        public static int nyckel { get; set; } // räknar om man har tagit upp en nyckel
        public static int yxa { get; set; }
        public static int vapen { get; set; }

    }
}
